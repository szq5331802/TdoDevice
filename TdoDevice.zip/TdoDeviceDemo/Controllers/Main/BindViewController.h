

@interface BindViewController : UIViewController

@end

